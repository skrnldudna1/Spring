package com.company.mapper;

import com.company.domain.MemberVO;

public interface MemberMapper {
	
	public MemberVO read(String userid);

}
