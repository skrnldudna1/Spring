package com.company;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.log4j.Log4j;

//테스트를 실행할 때 SpringJUnit4ClassRunner를 사용하
@RunWith(SpringJUnit4ClassRunner.class)
//Spring 설정 파일 위치를 지정 (데이터베이스와 보안 설정을 로드)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
						"file:src/main/webapp/WEB-INF/spring/security-context.xml"})
@Log4j
public class MemberTests {
	
	//스프링에서 자동으로 주입해주는 객체 ( 비밀번호를 암호화하는 도구)
	@Autowired
	private PasswordEncoder pwencoder;
	
	// 데이터베이스와 연결하는 객체 (DateSource)
	@Autowired
	private DataSource ds;


	// 첫번째 테스트 : tbl_member 테이블에 회원 데이터 삽입
	@Test
	public void testInsertMember() {
		//삽입하는 sql문
	    String sql = "insert into tbl_member(userid, userpw, username) values(?,?,?)";

	    //100명의 데이터를 생성해서 데이터베이스에 넣는 반복문
	    for (int i = 0; i < 100; i++) {
	        Connection con = null;
	        PreparedStatement pstmt = null;

	        try {
	        	//데이터베이스 연결 가져오기
	            con = ds.getConnection();
	            pstmt = con.prepareStatement(sql);

	            // userid 설정 (userid와 username을 다르게 설정
	            if (i < 80) { // 0 ~ 79번 사용자는 일반 사용자
	                pstmt.setString(1, "user" + i); // userid: user0, user1, ...
	                pstmt.setString(3, "일반사용자" + i); // username: 일반사용자0, 일반사용자1, ...
	            } else if (i < 90) {
	                pstmt.setString(1, "manager" + i);
	                pstmt.setString(3, "운영자" + i);
	            } else {
	                pstmt.setString(1, "admin" + i);
	                pstmt.setString(3, "관리자" + i);
	            }

	            // userpw 설정
	            pstmt.setString(2, pwencoder.encode("pw" + i));
	         // SQL 실행 (데이터베이스에 데이터 삽입)
	            pstmt.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	        	// 데이터베이스 리소스를 해제 (꼭 해줘야 함!)
	            if (pstmt != null) {
	                try {
	                    pstmt.close();
	                } catch (Exception e) {
	                }
	            }
	            if (con != null) {
	                try {
	                    con.close();
	                } catch (Exception e) {
	                }
	            }
	        }
	    }
	}

	
	@Test
	public void testInsertAuth() {

	    String sql = "insert into tbl_member_auth (userid, auth) values (?,?)";

	    for (int i = 0; i < 100; i++) {

	        Connection con = null;
	        PreparedStatement pstmt = null;

	        try {
	            con = ds.getConnection();
	            pstmt = con.prepareStatement(sql);

	            if (i < 80) {
	                pstmt.setString(1, "user" + i);
	                pstmt.setString(2, "ROLE_USER");
	            } else if (i < 90) {
	                pstmt.setString(1, "manager" + i);
	                pstmt.setString(2, "ROLE_MEMBER");
	            } else {
	                pstmt.setString(1, "admin" + i);
	                pstmt.setString(2, "ROLE_ADMIN");
	            }

	            pstmt.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            if (pstmt != null) {
	                try { pstmt.close(); } catch (Exception e) {}
	            }
	            if (con != null) {
	                try { con.close(); } catch (Exception e) {}
	            }
	        }
	    } // end for
	}
}
	
	
	

